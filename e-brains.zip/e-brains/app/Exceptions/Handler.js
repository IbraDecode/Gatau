export class Handler { static report(err) { console.error(err); } }
