import './2025_11_09_000000_create_users_table.js';
import './2025_11_09_000001_create_memories_table.js';
