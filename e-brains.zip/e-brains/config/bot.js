export default { forbiddenWords: [] };
