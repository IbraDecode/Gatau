export default { name: process.env.APP_NAME || 'E-Brains', env: process.env.NODE_ENV || 'development' };
