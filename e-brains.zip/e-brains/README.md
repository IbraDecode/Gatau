# E-Brains

Base Telegram bot starter using Telegraf v5 and modern ESM Node.js.

Quick start:

1. Copy `.env.example` to `.env` and fill TELEGRAM_TOKEN and DB_PATH.
2. npm install
3. node artisan migrate
4. node artisan seed
5. node artisan serve
