import assert from 'assert'; assert.strictEqual(1,1);
